
var a
var RaftX
var RaftY=290
var RaftWidth = 60
var RaftHeight = 10
var score=0
function setup() {
  createCanvas(400, 400);
  a=10
  x=200
  b=true
}

function draw() {
  background(252, 186, 3);
  fill(3, 140, 252)
  noStroke()
  rect(0,300,400,200)
  
//Raft on x axis follows mouse.
    RaftX=mouseX
fill(236, 239, 12 )
ellipse(200,200,100,100)
clouds(20,20)
push();
rotate(20)
clouds(100,20)
pop();
push();
scale(2)
clouds(180,20)
pop();
clouds(220,20)
clouds(320,20)
  
rain(50)
push() 
translate(10,10)
  
rain(250)
pop()
//If score is more than 2, more rain drops
if(score>2){ 
rain(300)
translate(20,20)
rain(50)
}
if(score>3){
rain(150)
}
fill(122, 75, 39)
rect(RaftX,RaftY,RaftWidth,RaftHeight)

//score display 
 push() 
fill(0, 255, 255)
textSize(24)
text("score: " + score,10,25 )
  pop()
//background clouds
}
function clouds (x,y){
fill(255, 255, 255)
ellipse(x,y,40,40)
fill(255, 255, 255)
ellipse(x+20,y,40,40)
fill(255, 255, 255)
ellipse(x+10,y+15,40,40)
fill(255, 255, 255)
ellipse(x+25,y+15,40,40)
}

//rain drops
function rain(b){

ellipse(b,a,10,10)
  a=a+0.25

 if(a>300){
  a=-1}
//Function watchs collusion and increases score
 if(a==RaftX&&RaftY&&RaftWidth&&RaftHeight){
   score++
    }
}
function raft(){
  fill(122, 75, 39)
rect(mouseX,290,RaftWidth,RaftHeight)
}